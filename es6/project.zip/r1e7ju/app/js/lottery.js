import './lottery/base.js';
import './lottery/timer.js';
import './lottery/calculate.js';
import './lottery/interface.js';
